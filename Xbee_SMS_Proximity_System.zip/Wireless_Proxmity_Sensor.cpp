/*
 *  Copyright � 1997-2002 Metrowerks Corporation.  All Rights Reserved.
 *
 *	Please see the stationery release note "Win32 Default Libs Notes.txt" 
 *	for information about using this stationery.
 *
 *  Questions and comments to:
 *       <mailto:support@metrowerks.com>
 *       <http://www.metrowerks.com/>
 */

#include <windows.h>
#include <iostream>
#include <cstring>

#include "Serial.h"

using namespace std;

int g_Buffer_Size = 256;
char *g_Buffer;

string g_strComPort = "COM3";
int g_BaudRate = 9600;

void Exit();
void Exit()
{
	cout << "Exiting program!\n";
}

int main()
{
	//Set function to excute when exiting program
	atexit(Exit);
	
	//Start application
	cout << "EECS 501 - Project 4: Wireless Proximity System\n";
	cout << "Created by: Matthew Hannon, Garrett Scarlett, Jerome Younger\n\n";

	g_Buffer = new char[g_Buffer_Size];

	//Initalize communication with IO port

  //  string str ("COM4");
  //  const char* comPort = str.c_str();

    Serial DataStream(g_strComPort, g_BaudRate);

    DataStream.flush();

    char strWrite[256];
    unsigned int number;
    
    bool Counting = false;
    DWORD StartCounter = 0, Duration = 0;
    //SYSTEMTIME *tempTime, tempTime1;
    
    while(true)
    {
	    DataStream.read(g_Buffer, g_Buffer_Size, true);
	    
	    number = atoi(g_Buffer);
	    cout << g_Buffer << "Distance: " << number << std::endl;
	    
	    if(number > 15 && !Counting)
	    {
	   		Counting = true;
	    	StartCounter = GetTickCount();
	   	}
	   	
	   	if(number <= 15 && Counting)
	   	{
	   		Counting = false;
	   		Duration = (GetTickCount() - StartCounter)/1000;
	  		cout << "Duration of time: " << Duration << endl;
	  		
	  		StartCounter = Duration = 0;
	  	}
	  	
	  	
	    Sleep(600);
	    
    }
    
    /*
    //Prepare to place the xbee in programming mode
    strcpy(strWrite, "+++");
    
    int bytesWritten = DataStream.write(strWrite);
    cout << bytesWritten << " bytes were written to the serial port" << endl;
    
    if(bytesWritten != strlen(strWrite))
    {
        cout << "Error: All the bytes were not written to serial port! Attemping to write: " << strWrite << endl;
    }
    
    Sleep(2500);

    int charsRead = DataStream.read(g_Buffer, g_Buffer_Size);
    cout << g_Buffer;
	
	
	//Things that are mandatory to set for basic Xbee communication
	//	-PAN ID to make sure both xbee on same network
	//	-MY  numeric name for xbee device
	//	-DL  numeric name of device going to talk to 


    //Write default settings
    bytesWritten = DataStream.write("ATRE\r");
    DataStream.read(g_Buffer, g_Buffer_Size);
    cout << g_Buffer << std::endl;
    Sleep(50);
   
    //set pan id which will be same for all 2 xbees
    bytesWritten = DataStream.write("ATID6666\r");
    charsRead = DataStream.read(g_Buffer, g_Buffer_Size);
    
    if(charsRead != 3)
    {
    	cout << "Error: Xbee didn't return OK when setting pan id network\n" << charsRead;
    	return 0;
    }
    
    cout << g_Buffer << std::endl;
    Sleep(50);
 
 
    //Now set the numeric name for the xbee device (both devices should have differnt names) 0 = reciever
    bytesWritten = DataStream.write("ATMY1\r");
    charsRead = DataStream.read(g_Buffer, g_Buffer_Size);
    
    if(charsRead != 3)
    {
    	cout << "Error: Xbee didn't return OK when setting name\n" << charsRead;
    	return 0;
    }
    
    cout << g_Buffer << std::endl;
    Sleep(50);
 
   
    //Now set the numeric name for the device the xbee is going to talk to 1 = transmitter
    bytesWritten = DataStream.write("ATDL0\r");
    charsRead = DataStream.read(g_Buffer, g_Buffer_Size);
    
    if(charsRead != 3)
    {
    	cout << "Error: Xbee didn't return OK when setting destination\n" << charsRead;
    	return 0;
    }
    
    cout << g_Buffer << std::endl;
    Sleep(50);
 
    //Now set the baud rate to 9600 bps which is 0x03
    bytesWritten = DataStream.write("ATBD3\r");
    charsRead = DataStream.read(g_Buffer, g_Buffer_Size);
    
    if(charsRead != 3)
    {
    	cout << "Error: Xbee didn't return OK when setting baudrate\n" << charsRead;
    	return 0;
    }
    
    cout << g_Buffer << std::endl;
    Sleep(50);
 
     //Now exit config mode, and then write to non-volatile memory
    bytesWritten = DataStream.write("ATCN\r");
    charsRead = DataStream.read(g_Buffer, g_Buffer_Size);
    
    if(charsRead != 3)
    {
    	cout << "Error: Xbee didn't return OK when setting destination\n" << charsRead;
    	return 0;
    }
    
    cout << g_Buffer << std::endl;
    Sleep(50);
 
    //Now set the baud rate to 9600 bps which is 0x03
    bytesWritten = DataStream.write("ATWR\r");
    charsRead = DataStream.read(g_Buffer, g_Buffer_Size);
    
    if(charsRead != 3)
    {
    	cout << "Error: Xbee didn't return OK when setting baudrate\n" << charsRead;
    	return 0;
    }
    
    cout << g_Buffer << std::endl;
    Sleep(50);
 
 
 */

 
 
	/*
	XBEE1:
ATID = 1111
ATMY = 10 name
ATDL = 11 talking to whom
ATBD = 5  baud rate (3 = 9600bps)
XBEE2:
ATID = 1111
ATMY = 11
ATDL = 10
ATBD = 5
	*/
	
	
	
	
	int temp;
	cin >> temp;
	
	return 0;
}


