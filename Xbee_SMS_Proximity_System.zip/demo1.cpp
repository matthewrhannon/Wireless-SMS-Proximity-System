//Wireless Proxmity Project






//Credit given to the following for email utilities:
// jwSMTP library
//   http://johnwiggins.net
//   smtplib@johnwiggins.net
//
//#include <windows.h>
#include <iostream>
#include <cstring>

// Please note the jwsmtp library has to be installed
// for this next header to work.
#include "jwsmtp/jwsmtp.h"

#include "Serial.h"

using namespace std;

int g_Buffer_Size = 256;
char *g_Buffer;

string g_strComPort = "COM5";
int g_BaudRate = 9600;

void Exit();
void Exit()
{
	cout << "Exiting program!\n";
}

int main(int argc, char* argv[])
{
	//Set function to execute when exiting program
	atexit(Exit);
	
	//Start application
	cout << "EECS 501 - Project 4: Wireless Proximity System\n";
	cout << "Created by: Matthew Hannon, Garrett Scarlett, Jerome Younger\n\n";
	cout << "Final\n";
	g_Buffer = new char[g_Buffer_Size];

	//Initalize communication with IO port

  //  string str ("COM4");
  //  const char* comPort = str.c_str();

	try{
		Serial DataStream(g_strComPort, g_BaudRate);


    DataStream.flush();

    char strWrite[256];
    unsigned int number;
    
    bool Counting = false;
    DWORD StartCounter = 0, Duration = 0;
	char strBuffer[64];
	int oldDistance = 0;
    while(true)
    {
	    DataStream.read(g_Buffer, g_Buffer_Size, true);
	    
	    number = atoi(g_Buffer);
	    cout << g_Buffer << "Distance: " << number << std::endl;
	    
	    if(number > 15 && !Counting)
	    {
			oldDistance = number;
	   		Counting = true;
	    	StartCounter = GetTickCount();
	   	}
	   	
	   	if(number <= 15 && Counting)
	   	{
	   		Counting = false;
	   		Duration = (GetTickCount() - StartCounter)/1000;
	  		cout << "Duration of time: " << Duration << endl;
			if(Duration > 10)
			{
				cout << "Greater than 10 so sending message!\n";

				sprintf(strBuffer, "!Proximity Detection! Duration: %d Distance %d. Send People!", Duration, oldDistance);
				// replace the users 'to' and 'from' here before compiling this demo
				jwsmtp::mailer m("7858656544@txt.att.net", "sms_account501@yahoo.com", "Wireless Proxmity Alert System",
					strBuffer, "localhost",
					jwsmtp::mailer::SMTP_PORT, false);


				//  m.setmessageHTML(html);
				m.setserver("smtp.mail.yahoo.com");
				m.authtype(jwsmtp::mailer::LOGIN);
				m.username("sms_account501@yahoo.comD");
				m.password("eecs501");

				m.send(); // send the mail

				std ::cout << m.response() << "\n";

			}
			








	  		StartCounter = Duration = 0;
	  	}
	  	
	  	
	    Sleep(600);
	    
    }
}
	catch(char * str )
	{
		cout << str << endl;
	}
	//Wait for user input as not to see output on console
	char temp;
	cin >> temp;

	if(temp == 'c')
	{
		cout << "attempting to text msg\n";
					jwsmtp::mailer m("9133065798@txt.att.net", "sms_account501@yahoo.com", "subjec",
							"Thank you justiN!", "localhost",
							jwsmtp::mailer::SMTP_PORT, false);
			

			//  m.setmessageHTML(html);
			m.setserver("smtp.mail.yahoo.com");
			m.authtype(jwsmtp::mailer::LOGIN);
			m.username("sms_account501@yahoo.comD");
			m.password("eecs501");

			m.send(); // send the mail

			std ::cout << m.response() << "\n";






	}

   return 0;
}
